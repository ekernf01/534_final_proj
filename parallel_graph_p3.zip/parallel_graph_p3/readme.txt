Eric Kernfeld 
Stat 534 final project submission
Problem 3

To compile: make
To run:  mpirun -np 10 parallel_graph 


Thanks for all the work you’ve put into the course. I hope you enjoy your summer!
Eric
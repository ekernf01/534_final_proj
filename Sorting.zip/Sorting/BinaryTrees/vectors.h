#include <stdio.h>
#include <math.h>
#include <string.h>

double* allocvector(int n);
void printvector(double* v,int n);
void freevector(double* v);
void vectorproduct(int n,double* v1,double* v2,double* v);
void readvector(int n,double* v,char* filename);

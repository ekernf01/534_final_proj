Eric Kernfeld 
Stat 534 final project submission
Problem 2

To compile: make
To run: ./graphs
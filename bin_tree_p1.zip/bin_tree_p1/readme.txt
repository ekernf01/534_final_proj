Eric Kernfeld 
Stat 534 final project submission
Problem 1

To compile: make
To run: ./bintree
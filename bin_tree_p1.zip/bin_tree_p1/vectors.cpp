#include "vectors.h"
using namespace std;

//dynamically allocates a vector of double of length n
double* allocvector(int n)
{
	int i;
	
	//that's where the memory gets allocated
	double * v = new double[n];
	
	//we set the elements of our vector to zero
	
	/*
	for(i=0;i<n;i++)
	{
		v[i] = 0;
	}
	 */
	//the code above is slow
	//it's better and faster to use
	memset(v,0,n*sizeof(double));
	
	
	return(v);
}

//prints the elements of a vector of length n
void printvector(double* v,int n)
{
	int i;
	
	for(i=0;i<n;i++)
	{
		printf("element [%d] = %.3lf\n",i+1,v[i]);
	}
	
	return;
}

//prints the elements of a vector of length n to the file "filename".
void fprintvector(double* v,int n, char* filename)
{
	FILE* stream = fopen(filename,"r");

   if(NULL==stream)
   {
		printf("Cannot open file [%s]\n",filename);
   }
	int i;
	
	for(i=0;i<n;i++)
	{
		fprintf(stream, "element [%d] = %.3lf\n",i+1,v[i]);
	}
	
	fclose(stream);
	return;
}






//frees the memory of this vector
void freevector(double* v)
{
	delete[] v; v = NULL; 
	return;
}

//calculates the dot product ofvectors v1 and v2 and saves the result in v
void vectorproduct(int n,double* v1,double* v2,double* v)
{
	int i;
	
	for(i=0;i<n;i++)
	{
		v[i] = v1[i]*v2[i];
	}
	
	return;
}

//reads a vector from a file
void readvector(int n,double* v,char* filename)
{
   FILE* in = fopen(filename,"r");

   if(NULL==in)
   {
      printf("Cannot open file [%s]\n",filename);
   }

   double s;
   for(int i=0;i<n;i++)
   {
      fscanf(in,"%lf",&s);
      v[i] = s;
   }
 
   fclose(in);

   return;
}
